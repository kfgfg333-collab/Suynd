import { config } from "dotenv";
import path from "node:path";

config({ quiet: true });

function required(name: string): string {
  const value = process.env[name]?.trim();
  if (!value) {
    console.error(`❌ Переменная ${name} не задана. Скопируйте .env.example в .env и заполните её.`);
    process.exit(1);
  }
  return value;
}

const isProd = process.env.NODE_ENV === "production";

export const env = {
  isProd,
  botToken: required("BOT_TOKEN"),
  allowedUserId: Number(required("ALLOWED_USER_ID")),
  webappUrl: (process.env.WEBAPP_URL ?? "http://localhost:5173").replace(/\/$/, ""),
  port: Number(process.env.PORT ?? 3000),
  dataDir: path.resolve(process.env.DATA_DIR ?? "./data"),
  sessionSecret: process.env.SESSION_SECRET || required("BOT_TOKEN"),
  devAuthBypass: !isProd && process.env.DEV_AUTH_BYPASS === "true",
  // Отключить бота (например, для локальных тестов без интернета до Telegram)
  botDisabled: process.env.BOT_DISABLED === "true",
};

if (!Number.isFinite(env.allowedUserId) || env.allowedUserId <= 0) {
  console.error("❌ ALLOWED_USER_ID должен быть числом — вашим Telegram ID.");
  process.exit(1);
}
